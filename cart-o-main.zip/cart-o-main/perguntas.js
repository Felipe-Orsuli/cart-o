criaCartao(
    'Conhecimentos Gerais',
    'Quem foi a primeira pessoa a viajar no Espaço?',
    'Yuri Gagarin'
)

criaCartao(
    'Conhecimentos Gerais',
    'Qual a montanha mais alta do mundo?',
    'Monte Everest'
)

criaCartao(
    'Conhecimentos Gerais',
    'Onde se localiza Machu Picchu?',
    'Peru'
)

criaCartao(
    'Conhecimento Gerais',
    'Que país tem o formato de uma bota?',
    'Itália'
)